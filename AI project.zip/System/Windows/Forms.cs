﻿namespace System.Windows
{
    internal class Forms
    {
        public static object MessageBox { get; internal set; }
    }
}